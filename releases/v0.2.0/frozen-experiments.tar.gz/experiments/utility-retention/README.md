# Utility retention v0.2 — Stage 1 & Stage 2

实现位置：`utility_retention/` 唯一包（dataset、engine、labeling、runner、prediction、policies、baselines、e2_metrics）；`run.py` 编排 E1，`evaluate.py` 独立验证 E1，`e2.py` 开发预测器，`e3_baselines.py` 补齐正式测试前的启发式基线。复用共享配置、I/O、哈希、embedding 和 generation；不修改 v0.1 结果。Stage 3 正式比较与 Stage 4 尚未实施。

在仓库根目录运行：

```bash
.venv/bin/python experiments/utility-retention/run.py --backend test --output experiments/utility-retention/results/pilot-test
.venv/bin/python experiments/utility-retention/evaluate.py experiments/utility-retention/results/pilot-test
.venv/bin/python -m pytest tests/test_utility_retention.py
```

真实模型开发 pilot（先准备独立数据并校准算力预算）：

```bash
.venv/bin/python experiments/utility-retention/run.py --backend model --model-config configs/local.yaml --dataset /path/to/development-trajectories.json --output experiments/utility-retention/results/pilot-model
```

可通过 `--config` 指定 pilot JSON，通过 `--seed` 设起始 seed；后续重复依次加一。原样重跑同一命令可续跑；输入、模型文件摘要、源码、协议或参数改变时拒绝复用目录。模型文件首次哈希可能较慢。

输出：manifest、完整 dataset/split 清单、history-features、responses.jsonl、query-utility、future-value-labels、reliability-report；独立验证额外写 verification.json。内置测试生成器直接返回证据文本，通常产生全零标签，这是有意保留的工程检查结果，不是效用证据。符号与稳定性用受控测试单独验证。

字段和限制见 [protocol.md](protocol.md)。工程检查与真实模型实验分目录保存；已执行实验及冻结协议见下文。近重复语义分组与窗口连续性依赖上游数据清单，不能仅靠本地字段检查证明。

## 已执行的真实模型实验

基础 model pilot 已完成，见 [pilot 报告](results/pilot-model/report.md)：144 条真实推理，18 个 storage 标签（12 正、6 零）。这是基础合成任务测量结果。

扩展 E1 使用 [冻结协议](protocol-e1-frozen.md)，独立于 pilot 的 12 条轨迹，四类压力场景，三次重复。执行命令：

```bash
.venv/bin/python experiments/utility-retention/run.py --backend model --model-config configs/local.yaml --dataset experiments/utility-retention/datasets/e1-frozen.json --config experiments/utility-retention/configs/e1-frozen.json --protocol experiments/utility-retention/protocol-e1-frozen.md --output experiments/utility-retention/results/e1-model-frozen
.venv/bin/python experiments/utility-retention/evaluate.py experiments/utility-retention/results/e1-model-frozen
.venv/bin/python experiments/utility-retention/report.py experiments/utility-retention/results/e1-model-frozen
```

GPU 实验需在可访问 GPU 的执行环境中运行；沙箱内看不到 GPU 不表示宿主机无 GPU。最终运行状态以 manifest 为准。扩展实验保留 source-snapshot 与 frozen-inputs，便于源码变化后追溯；原输出目录续跑仍要求当前源码身份严格匹配。

## E1 扩展（独立版本）

[扩展协议](protocol-e1-extension.md) 固定48条新轨迹（train24 / validation12 / test12），192个候选memory标签，三次重复；9条开发互补轨迹额外执行四种证据对照。主实验使用原有模型、prompt和评分，诊断不访问测试轨迹。

```bash
.venv/bin/python experiments/utility-retention/run.py --backend model --model-config configs/local.yaml --dataset experiments/utility-retention/datasets/e1-extension.json --config experiments/utility-retention/configs/e1-extension.json --protocol experiments/utility-retention/protocol-e1-extension.md --output experiments/utility-retention/results/e1-extension-model
.venv/bin/python experiments/utility-retention/diagnose_e1.py --backend model --model-config configs/local.yaml --main-output experiments/utility-retention/results/e1-extension-model --output experiments/utility-retention/results/e1-extension-diagnostic
.venv/bin/python experiments/utility-retention/evaluate.py experiments/utility-retention/results/e1-extension-model
.venv/bin/python experiments/utility-retention/report_extension.py --main-output experiments/utility-retention/results/e1-extension-model --diagnostic-output experiments/utility-retention/results/e1-extension-diagnostic
.venv/bin/python experiments/utility-retention/audits/verify_run.py experiments/utility-retention/results/e1-extension-model
```

状态以各目录manifest为准。主结果在 `e1-extension-model`，互补对照原始结果在 `e1-extension-diagnostic`。完成后生成 `extension-report.md` 和 `handoff/`，训练/验证特征及标签分别存储，测试仅供特征表与独立 hindsight 标签文件，未训练预测器。若未来源码改变，请使用已归档版本恢复运行/审计环境；不得修改原manifest绕过身份检查。

扩展已完成：主实验2304次、开发诊断216次，审计通过。结果见 [扩展报告](results/e1-extension-model/extension-report.md) 和 [解释与限制](results/e1-extension-model/interpretation.md)。原始和派生数据均已保存；E1开发门槛通过，E2已完成并冻结主预测器。

## Stage 2：历史价值预测开发

入口 `e2.py`；实现复用唯一包中的 `prediction.py`、`policies.py`、`e2_metrics.py`、`e2.py`。协议见 [protocol-e2-development.md](protocol-e2-development.md)。首轮13个候选（零预测 + 四组特征各三个Ridge正则化参数），在验证集比较预算内真实回答表现后冻结全特征组主模型。只读取训练/验证交接数据；未开展E3正式测试。

```bash
.venv/bin/python experiments/utility-retention/e2.py prepare --backend model --model-config configs/local.yaml --output experiments/utility-retention/results/e2-development-model
.venv/bin/python experiments/utility-retention/e2.py run --backend model --model-config configs/local.yaml --output experiments/utility-retention/results/e2-development-model
.venv/bin/python experiments/utility-retention/e2.py audit --output experiments/utility-retention/results/e2-development-model
```

`prepare`必须使用空目录，保存源码和输入快照，先冻结所有子集再打开验证任务。`run`可用原命令续跑；严格校验源码/模型/输入身份，只复用同一运行内完全相同的快照、子集、问题和seed，不复用旧E1回答。`audit`重新拟合训练模型并重算预测、选择、评分和模型选择，验证冻结产物。正式推理前不编辑已冻结Python源码；修订使用新输出。

主要输出：models.json、prediction-metrics.json、plans.json、predictions.json、responses.jsonl、summary.json、model-selection.json、frozen-predictor.json、audit.json、report.md、manifest.json。测试后端必须使用独立目录和 `--backend test`，仅检查流程。10%预算是空集参照，不参与模型选择；provenance特征未进入本轮模型。本轮不声称完整实施E3或E4。

### E3 前基线补齐

Stage 2 完成后，使用 `e3_baselines.py` 在同一验证集上补齐 `importance` 与 `semantic_dedup` 启发式基线，并冻结正式 E3 测试前需要的策略边界。该步骤不重新训练 `full-a10`，不更改 E2 冻结预测器，只新增开发基线比较。

```bash
.venv/bin/python experiments/utility-retention/e3_baselines.py prepare --backend model --output experiments/utility-retention/results/e3-baselines-development-model
.venv/bin/python experiments/utility-retention/e3_baselines.py run --backend model --model-config configs/local.yaml --output experiments/utility-retention/results/e3-baselines-development-model
.venv/bin/python experiments/utility-retention/e3_baselines.py audit --output experiments/utility-retention/results/e3-baselines-development-model
```

补齐结果见 [E3基线开发报告](results/e3-baselines-development-model/report.md) 和 [冻结策略](results/e3-baselines-development-model/frozen-strategies.json)：importance评分48次，有效率100%；新增回答评估144次；选定 `semantic_dedup` 阈值0.8；正式测试前最强启发式为 `importance`。正式 E3 仍未执行，协议和机器可读配置已冻结在 [protocol-e3-formal-test.md](protocol-e3-formal-test.md)、[configs/e3-formal-test.json](configs/e3-formal-test.json) 与 [e3-formal-freeze-manifest.json](e3-formal-freeze-manifest.json)。

命名边界：E1 的 `condition` 表示删除/对照干预，例如 `storage_deletion`、`context_deletion`、`full`、`no_memory`；E2/E3 的 `candidate` 表示保留策略或模型候选，例如 `full-a10`、`recency`、`importance`。`full` 和 `no_memory` 会在两层同时出现，但前者是标签构造条件，后者是保留策略参照，校验 key 和指标路径不同。E3 复用 E2 的选择、响应校验、汇总和配对差异函数；各阶段保留独立 `prepare/run/audit/report` 胶水，用来维持不同冻结边界。

## E3 正式测试

正式入口为 `e3_formal.py`，包模块为 `utility_retention.e3_formal`。原始冻结协议与配置保留；运行前补充说明见 `protocol-e3-formal-clarification.md`。正式预测器固定 full-a10，主比较固定 importance。

```bash
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_formal.py prepare --backend model --output experiments/utility-retention/results/e3-formal-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_formal.py run --backend model --output experiments/utility-retention/results/e3-formal-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_formal.py audit --output experiments/utility-retention/results/e3-formal-model
```

`run` 支持身份一致续跑；`prepare` 拒绝非空目录。模型路径统一经 `load_config` / `--model-config` 读取。`--backend test` 使用独立fixture seeds，只验证工程流程。正式 seeds 与各策略 seeds 来自冻结配置，不开放命令行调参。

复用边界：`Engine` / `historical_features` / `score` / `serialize`、`prediction.predict`、`policies.select` / `baseline_scores`、补充基线 `plans_from_past` / `verify_importance`、E2 `expected_conditions` / `verify_responses` / `summarize` / `paired`。E3仅编排正式生命周期，并在新报告中纠正旧 `paired` 返回值的 validation 描述。没有修改旧模块或动态加载其他阶段的同名runner。

E1的`condition/deleted_memory_id`用于干预；E3的`candidate`用于策略。独立`diagnostic-plans.json`中的storage_deletion只用于请求删除条件，不进入策略排名；`hindsight-labels.json`使用`loo_value`，只在汇总adapter中转换为旧E2标签接口。正式语义去重策略名统一为`semantic_dedup`，阈值存入冻结配置。预测器ID`full-a10`与保留策略`full`互不混用。

新运行保存数据/源码快照、历史视图、特征、importance原始输出、预测、分阶段计划、回答、LOO标签、配对统计、支持集诊断、成本报告、预算图和审计。`deployable-complete.json`封存第一阶段回答前缀，保证事后LOO诊断不会倒流到可部署选择。

本轮正式模型运行已完成：结果见 `results/e3-formal-model/report.md`，实施和解释见 `docs/v0.2-stage3-implementation-log.md`（相对项目根目录）。96次importance、600次唯一回答生成，正式审计通过。主比较utility-aware对importance的三预算平均EM差异为+0.2014，描述性95%区间[0.0972, 0.3056]。原冻结输入的executed字段保留原样；实际状态以结果manifest顶层为准。

## E3 补充分析和强模型审计

补充入口为 `e3_supplement.py` / `utility_retention.e3_supplement`，默认父运行是 `results/e3-formal-model`。协议见 `protocol-e3-supplement.md`，独立输出 `results/e3-supplement-model`；原正式数据、源码和产物hash保持不变。

```bash
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_supplement.py prepare --output experiments/utility-retention/results/e3-supplement-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_supplement.py run --output experiments/utility-retention/results/e3-supplement-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e3_supplement.py audit --output experiments/utility-retention/results/e3-supplement-model
```

`run` 在同一模型下重算历史特征、相似度、检索与token数，不生成答案、importance评分或重新训练。GPU不可见时需要宿主运行环境。支持身份一致续跑；COMPLETE再次run只读审计。`--parent`可指定已有完整工程fixture，后端继承父manifest；`--model-config`沿用公共配置入口。

模块边界：`e3_supplement_analysis`只读分析；`e3_supplement_replay`复用冻结scorer/selector/Engine做重算与计时；`e3_supplement`负责独立生命周期和补充报告。沿用`candidate`表示策略，`category`和`diagnostic.*`仅表示观察到的失败位置，不新增同名策略或修改E1的condition。

主要产物：`failure-analysis.json`、`gain-distribution.json`、`history-replay.json`、`retrieval-replay.jsonl`、`token-replay.json`、`microbenchmark.json`、`cost-accounting.json`、`e4-cases.md/json`、`report.md`和`audit.json`。新微基准与原始计时分开，不拼接为端到端延迟。案例为事后交接材料，不作为新E4盲测。

补充模型运行现已COMPLETE：96行历史特征、24组相似度、600条件检索和960条计划重算一致，全部数值最大差异为0；180条微基准记录，8个E4案例。全仓91项测试通过。实施解释见项目根目录下 `docs/v0.2-stage3-supplement-log.md`。

## E4 集合依赖诊断

入口 `e4.py` → `utility_retention.e4`；分析、上下文干预和报告分别在 `e4_analysis`、`e4_controls`、`e4_report`。协议见 [protocol-e4-diagnostic.md](protocol-e4-diagnostic.md)，独立输出 `results/e4-diagnostic-model`。E1–E3冻结模块不修改。

```bash
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e4.py prepare --backend model --output experiments/utility-retention/results/e4-diagnostic-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e4.py run --backend model --model-config configs/local.yaml --output experiments/utility-retention/results/e4-diagnostic-model
PYTHONPATH=src:experiments/utility-retention .venv/bin/python experiments/utility-retention/e4.py audit --output experiments/utility-retention/results/e4-diagnostic-model
```

`--parent`默认E3正式模型目录；测试后端要求先生成相同后端的独立E3 fixture，并使用新E4输出目录。GPU运行需宿主GPU可见环境。prepare拒绝非空目录；run支持同身份续跑，COMPLETE再次调用仅只读审计。配置从公共load_config/--model-config读取，种子来自冻结配置。

两组各24轨迹分别为 `e3_posthoc`（既有测试事后解释）和 `e4_independent`（新实体/事实、相同语法），每条N=4/H=2，完整枚举16子集。先封存可部署选择，再评估未来；只在父模型、源码、输入及参数身份核验后继承600条回答，不仅凭ID缓存。每个预算的best_subset在独立调用中复核；互补场景另做正序/反序和不补位上下文删除。

命名边界：`candidate=predicted_sum_optimal`是仅历史预测的精确加总选择；`candidate=hindsight_loo_sum_optimal`是未来LOO精确加总诊断；原`hindsight_loo`仍是LOO加原排序选择器。`best_subset`表示枚举实际EM最优，非线上上界。它们为E4局部候选，未改冻结contracts。`diagnostic=subset_enumeration`和`condition=context_*`不进入策略排名；上下文条件有单独key和JSONL，不占用E1存储删除语义。`cohorts.json`是输入分组映射，`cohort-summaries.json`才是分析输出。

复用：Engine/historical_features/score/serialize、make_deployable（内部调用predict/select及基线）、hindsight_plans/loo_labels、expected_conditions/verify_responses、summarize/paired、failure_analysis、公共I/O与model_identity。阶段独立生命周期维护自己的冻结边界，无动态导入runner、fit或全局路径替换。

主要产物：`subset-scores.json`、`labels.json`、`plans.json`、`ties.json`（含全部加总最优集合和EM范围）、`interactions.json`（所有记忆对及背景）、`cohort-summaries.json`（含分组失败归因和配对统计）、`scenario-checks.json`、`winner-repeats.jsonl`/`winner-stability.json`、`context-plans.json`/`context-controls.jsonl`、`cost-report.json`、`report.md`、`cases.md`、`audit.json`。命名和结果解释见第四阶段实施日志。

E4真实模型运行已COMPLETE，98项测试通过。1536个枚举条件、186个独立最佳集合复核、96个上下文对照均完成；主审计和独立bit-mask验算通过。复核无答案变化，原E3保持不变。结果见[正式报告](results/e4-diagnostic-model/report.md)，解释与v0.3方向见项目根目录[第四阶段日志](../../docs/v0.2-stage4-implementation-log.md)。
