# E4案例交接：来自E3的事后诊断

Post-hoc E3 examples, not blind E4 data; no subset enumeration or causal attribution

## e3-case-01：budget_infeasible

snapshot=s-0ffd5159ac64；query=q-457908e58552；budget=25%。
问题：Give the complete access code needed to open Locker-X2e3cf82e.；答案：284267；支持集：[['m-aeb2d7ee7429'], ['m-5a6ed297191a']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-aeb2d7ee7429 | 59 | 0.4607 | 0.0000 | Use 284267 as the access code to open Locker-X2e3cf82e. This record was transcribed from the local register. |
| m-19fa297e16ef | 47 | 0.1933 | 0.0000 | The maintenance ticket for Locker-X2e3cf82e is 21822. |
| m-d72084674691 | 61 | -0.0421 | 0.0000 | The inventory label for Locker-X2e3cf82e is 41182. The facilities clerk recorded this entry during a routine inventory review. |
| m-5a6ed297191a | 63 | 0.1364 | 0.0000 | To open Locker-X2e3cf82e, enter the access code 284267. The facilities clerk recorded this entry during a routine inventory review. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-19fa297e16ef'] | ['m-19fa297e16ef'] | 21822 | 0 |
| importance | ['m-19fa297e16ef'] | ['m-19fa297e16ef'] | 21822 | 0 |
| hindsight_loo | [] | [] | UNKNOWN | 0 |
| full | ['m-19fa297e16ef', 'm-5a6ed297191a', 'm-aeb2d7ee7429', 'm-d72084674691'] | ['m-5a6ed297191a', 'm-aeb2d7ee7429', 'm-19fa297e16ef'] | 284267 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-02：budget_infeasible

snapshot=s-1de27aac86dc；query=q-2e4501ded00a；budget=25%。
问题：What is the six-digit access code for Cabinet-X44df99fa?；答案：194274；支持集：[['m-33303e8f15f5']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-c609e2e07a6a | 57 | -0.0972 | 0.0000 | The service desk reference for Cabinet-X44df99fa is 98669. This record was transcribed from the local register. |
| m-33303e8f15f5 | 61 | 0.3799 | 1.0000 | Cabinet-X44df99fa opens with access code 194274. The facilities clerk recorded this entry during a routine inventory review. |
| m-138ed9dabaad | 52 | 0.0803 | 0.0000 | The maintenance ticket for Cabinet-X44df99fa is 80133. This record was transcribed from the local register. |
| m-b3d069e26a26 | 56 | 0.1488 | 0.0000 | The inventory label for Cabinet-X44df99fa is 44210. This record was transcribed from the local register. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-b3d069e26a26'] | ['m-b3d069e26a26'] | 44210 | 0 |
| importance | ['m-138ed9dabaad'] | ['m-138ed9dabaad'] | 80133 | 0 |
| hindsight_loo | [] | [] | UNKNOWN | 0 |
| full | ['m-138ed9dabaad', 'm-33303e8f15f5', 'm-b3d069e26a26', 'm-c609e2e07a6a'] | ['m-33303e8f15f5', 'm-b3d069e26a26', 'm-c609e2e07a6a'] | 194274 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-03：support_not_retained

snapshot=s-3f0e4b88d23e；query=q-2f507b8fc2a3；budget=50%。
问题：What is the six-digit access code for Cabinet-X92bf5151?；答案：620278；支持集：[['m-6b1d980aeb22']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-6b1d980aeb22 | 48 | 0.1595 | 1.0000 | The access code for Cabinet-X92bf5151 is 620278. |
| m-f295f537f8f9 | 49 | -0.1708 | 0.0000 | The service desk reference for Cabinet-X92bf5151 is 66736. |
| m-f34fdcd14590 | 46 | 0.1208 | 0.0000 | The maintenance ticket for Cabinet-X92bf5151 is 50042. |
| m-303596f47ccb | 59 | 0.3357 | 0.0000 | The inventory label for Cabinet-X92bf5151 is 11767. The facilities clerk recorded this entry during a routine inventory review. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-303596f47ccb'] | ['m-303596f47ccb'] | UNKNOWN | 0 |
| importance | ['m-303596f47ccb'] | ['m-303596f47ccb'] | UNKNOWN | 0 |
| hindsight_loo | ['m-6b1d980aeb22'] | ['m-6b1d980aeb22'] | 620278 | 1 |
| full | ['m-303596f47ccb', 'm-6b1d980aeb22', 'm-f295f537f8f9', 'm-f34fdcd14590'] | ['m-6b1d980aeb22', 'm-f295f537f8f9', 'm-303596f47ccb'] | 620278 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-04：support_not_retained

snapshot=s-70863a07ffa2；query=q-675314776c2f；budget=50%。
问题：Give the complete access code needed to open Locker-X6e6d497a.；答案：578883；支持集：[['m-23c2f9dbdbb4']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-23c2f9dbdbb4 | 60 | 0.2637 | 1.0000 | Locker-X6e6d497a opens with access code 578883. The facilities clerk recorded this entry during a routine inventory review. |
| m-93b5499d8b0e | 60 | 0.4029 | 0.0000 | The service desk reference for Locker-X6e6d497a is 98685. This record was transcribed from the local register. |
| m-9f0f3b2a7016 | 50 | 0.1992 | 0.0000 | The maintenance ticket for Locker-X6e6d497a is 83081. |
| m-11482cdcec5c | 60 | -0.0314 | 0.0000 | The inventory label for Locker-X6e6d497a is 42570. The facilities clerk recorded this entry during a routine inventory review. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-93b5499d8b0e', 'm-9f0f3b2a7016'] | ['m-9f0f3b2a7016', 'm-93b5499d8b0e'] | 98685 | 0 |
| importance | ['m-11482cdcec5c', 'm-9f0f3b2a7016'] | ['m-9f0f3b2a7016', 'm-11482cdcec5c'] | 83081 | 0 |
| hindsight_loo | ['m-23c2f9dbdbb4'] | ['m-23c2f9dbdbb4'] | 578883 | 1 |
| full | ['m-11482cdcec5c', 'm-23c2f9dbdbb4', 'm-93b5499d8b0e', 'm-9f0f3b2a7016'] | ['m-23c2f9dbdbb4', 'm-9f0f3b2a7016', 'm-11482cdcec5c'] | 578883 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-05：redundancy_hindsight

snapshot=s-0ffd5159ac64；query=q-457908e58552；budget=50%。
问题：Give the complete access code needed to open Locker-X2e3cf82e.；答案：284267；支持集：[['m-aeb2d7ee7429'], ['m-5a6ed297191a']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-aeb2d7ee7429 | 59 | 0.4607 | 0.0000 | Use 284267 as the access code to open Locker-X2e3cf82e. This record was transcribed from the local register. |
| m-19fa297e16ef | 47 | 0.1933 | 0.0000 | The maintenance ticket for Locker-X2e3cf82e is 21822. |
| m-d72084674691 | 61 | -0.0421 | 0.0000 | The inventory label for Locker-X2e3cf82e is 41182. The facilities clerk recorded this entry during a routine inventory review. |
| m-5a6ed297191a | 63 | 0.1364 | 0.0000 | To open Locker-X2e3cf82e, enter the access code 284267. The facilities clerk recorded this entry during a routine inventory review. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-19fa297e16ef', 'm-aeb2d7ee7429'] | ['m-aeb2d7ee7429', 'm-19fa297e16ef'] | 284267 | 1 |
| importance | ['m-19fa297e16ef', 'm-5a6ed297191a'] | ['m-5a6ed297191a', 'm-19fa297e16ef'] | 284267 | 1 |
| hindsight_loo | [] | [] | UNKNOWN | 0 |
| full | ['m-19fa297e16ef', 'm-5a6ed297191a', 'm-aeb2d7ee7429', 'm-d72084674691'] | ['m-5a6ed297191a', 'm-aeb2d7ee7429', 'm-19fa297e16ef'] | 284267 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-06：redundancy_hindsight

snapshot=s-2b4f98ab8742；query=q-0a106ec5d138；budget=25%。
问题：What is the six-digit access code for Locker-X66daed3c?；答案：613759；支持集：[['m-eb32d966f53a'], ['m-bd4b62801ebf']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-7556831cc319 | 47 | 0.0115 | 0.0000 | The inventory label for Locker-X66daed3c is 54438. |
| m-bd4b62801ebf | 61 | 0.2573 | 0.0000 | To open Locker-X66daed3c, enter the access code 613759. The facilities clerk recorded this entry during a routine inventory review. |
| m-922f4f2301f6 | 60 | 0.2034 | 0.0000 | The maintenance ticket for Locker-X66daed3c is 50702. The facilities clerk recorded this entry during a routine inventory review. |
| m-eb32d966f53a | 48 | 0.3691 | 0.0000 | The access code for Locker-X66daed3c is 613759. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-eb32d966f53a'] | ['m-eb32d966f53a'] | 613759 | 1 |
| importance | ['m-7556831cc319'] | ['m-7556831cc319'] | 54438 | 0 |
| hindsight_loo | [] | [] | UNKNOWN | 0 |
| full | ['m-7556831cc319', 'm-922f4f2301f6', 'm-bd4b62801ebf', 'm-eb32d966f53a'] | ['m-eb32d966f53a', 'm-bd4b62801ebf', 'm-7556831cc319'] | 613759 | 1 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-07：complementarity_generation

snapshot=s-2b6334d33548；query=q-0a051694ace8；budget=75%。
问题：What is the six-digit access code for Locker-X48fc0dfe?；答案：880106；支持集：[['m-27ca54631c0f', 'm-5891834a4270']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-a7e1a84e2efa | 59 | 0.1267 | 0.0000 | The maintenance ticket for Locker-X48fc0dfe is 70793. The facilities clerk recorded this entry during a routine inventory review. |
| m-27ca54631c0f | 62 | 0.1999 | 0.5000 | The first three digits of the six-digit access code for Locker-X48fc0dfe are 880. This record was transcribed from the local register. |
| m-5891834a4270 | 63 | 0.3412 | 0.5000 | The last three digits of the six-digit access code for Locker-X48fc0dfe are 106. This record was transcribed from the local register. |
| m-b67bf4173d18 | 56 | -0.0700 | 0.0000 | The inventory label for Locker-X48fc0dfe is 26455. This record was transcribed from the local register. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-27ca54631c0f', 'm-5891834a4270'] | ['m-27ca54631c0f', 'm-5891834a4270'] | 880 | 0 |
| importance | ['m-5891834a4270', 'm-a7e1a84e2efa', 'm-b67bf4173d18'] | ['m-5891834a4270', 'm-a7e1a84e2efa', 'm-b67bf4173d18'] | 106 | 0 |
| hindsight_loo | ['m-27ca54631c0f', 'm-5891834a4270'] | ['m-27ca54631c0f', 'm-5891834a4270'] | 880 | 0 |
| full | ['m-27ca54631c0f', 'm-5891834a4270', 'm-a7e1a84e2efa', 'm-b67bf4173d18'] | ['m-27ca54631c0f', 'm-5891834a4270', 'm-a7e1a84e2efa'] | 880 | 0 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

## e3-case-08：complementarity_generation

snapshot=s-a6cd8196f1fb；query=q-3318a2753680；budget=75%。
问题：What is the six-digit access code for Vault-Xb1fdad26?；答案：252637；支持集：[['m-8dc57fbab17c', 'm-98c9ff8f9fc2']]。

| memory_id | tokens | 预测值 | LOO | 内容 |
|---|---:|---:|---:|---|
| m-2e044b6f9a31 | 59 | 0.2905 | 0.0000 | The maintenance ticket for Vault-Xb1fdad26 is 21452. The facilities clerk recorded this entry during a routine inventory review. |
| m-9ec49ed9aa9c | 53 | 0.1078 | 0.0000 | The inventory label for Vault-Xb1fdad26 is 87649. This record was transcribed from the local register. |
| m-8dc57fbab17c | 62 | 0.3301 | 0.0000 | The first three digits of the six-digit access code for Vault-Xb1fdad26 are 252. The facilities clerk recorded this entry during a routine inventory review. |
| m-98c9ff8f9fc2 | 60 | 0.3812 | 0.0000 | The last three digits of the six-digit access code for Vault-Xb1fdad26 are 637. This record was transcribed from the local register. |

| 策略 | 保留ID | 上下文ID | 实际输出 | EM |
|---|---|---|---|---:|
| utility_aware | ['m-8dc57fbab17c', 'm-98c9ff8f9fc2', 'm-9ec49ed9aa9c'] | ['m-98c9ff8f9fc2', 'm-8dc57fbab17c', 'm-9ec49ed9aa9c'] | 252 | 0 |
| importance | ['m-8dc57fbab17c', 'm-98c9ff8f9fc2', 'm-9ec49ed9aa9c'] | ['m-98c9ff8f9fc2', 'm-8dc57fbab17c', 'm-9ec49ed9aa9c'] | 252 | 0 |
| hindsight_loo | [] | [] | UNKNOWN | 0 |
| full | ['m-2e044b6f9a31', 'm-8dc57fbab17c', 'm-98c9ff8f9fc2', 'm-9ec49ed9aa9c'] | ['m-98c9ff8f9fc2', 'm-8dc57fbab17c', 'm-9ec49ed9aa9c'] | 252 | 0 |

完整response_key、预算、标注和数值见同名JSON；不得将该案例当作独立盲测。

未出现的类型：support_not_retrieved
